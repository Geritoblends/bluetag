import mqtt, { MqttClient } from 'mqtt';

const MQTT_BROKER = process.env.NEXT_PUBLIC_MQTT_BROKER || 'ws://localhost:9001';

let client: MqttClient | null = null;

export const getMQTTClient = (): MqttClient => {
  if (!client) {
    client = mqtt.connect(MQTT_BROKER);
    
    client.on('connect', () => {
      console.log('[v0] MQTT connected to', MQTT_BROKER);
    });

    client.on('error', (error) => {
      console.error('[v0] MQTT connection error:', error);
    });
  }
  
  return client;
};

export const emitSound = (macAddress: string) => {
  const client = getMQTTClient();
  const topic = `tags/${macAddress}/emit_sound`;
  client.publish(topic, '1');
  console.log('[v0] Emitted sound to', topic);
};

export const subscribeToDistance = (
  macAddress: string,
  callback: (distance: number) => void
) => {
  const client = getMQTTClient();
  const topic = `tags/${macAddress}/distance`;
  
  client.subscribe(topic, (err) => {
    if (err) {
      console.error('[v0] Failed to subscribe to', topic, err);
    } else {
      console.log('[v0] Subscribed to', topic);
    }
  });

  const messageHandler = (receivedTopic: string, message: Buffer) => {
    if (receivedTopic === topic) {
      const distance = parseFloat(message.toString());
      callback(distance);
    }
  };

  client.on('message', messageHandler);

  return () => {
    client.unsubscribe(topic);
    client.off('message', messageHandler);
  };
};

export const scanAvailableTags = (callback: (macAddress: string) => void) => {
  const client = getMQTTClient();
  const topic = 'availableTags/#';
  
  client.subscribe(topic, (err) => {
    if (err) {
      console.error('[v0] Failed to subscribe to availableTags', err);
    } else {
      console.log('[v0] Subscribed to availableTags');
    }
  });

  const messageHandler = (receivedTopic: string, message: Buffer) => {
    if (receivedTopic.startsWith('availableTags/')) {
      const macAddress = message.toString();
      callback(macAddress);
    }
  };

  client.on('message', messageHandler);

  return () => {
    client.unsubscribe(topic);
    client.off('message', messageHandler);
  };
};
